﻿using CreamsConsole_utils;
using System.Text;
using System.Drawing;



consoleAlloc.setupCreamsConsole();
Console.OutputEncoding = Encoding.UTF8;



var mainbody = new Conbox(new Boxsize(Console.WindowWidth-40, Console.WindowHeight-10),new COORD(0, 0), "mainbody");
var newbox = BoxOutline.createBoxOutline(mainbody);
var j2 =BoxOutline.createBoxOutline(newbox);


//Console.WriteLine(newbox.ToString());

conboxFunc.ConsolewriteMultiline(j2, new UCOORD(0, 0), "hallo ik ben een\ntest muliline ");





//var screem =conboxFunc.GetScreenCoord(mainbody);
//Console.WriteLine(screem.ToString());
//Console.WriteLine(mainbody.GetBoxRectuCoord().bottomright.ToString());
Console.ReadKey();