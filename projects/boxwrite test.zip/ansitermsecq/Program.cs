﻿using CreamsConsole_utils;

using System.Text;



consoleAlloc.setupCreamsConsole();
Console.OutputEncoding = Encoding.UTF8;

TermAnsiSec.setConsoleName("test");
TermAnsiSec.setCursorPos(5, 10);
Console.ReadKey();