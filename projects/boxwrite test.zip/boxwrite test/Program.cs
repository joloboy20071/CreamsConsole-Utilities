﻿using CreamsConsole_utils;
using CreamsConsole_utils.src;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;


// voor te testen of alle write mogelijkheden nog werken




var wueeejn = new eventqueue();
consoleAlloc.setupCreamsConsole();
consoleAlloc.ResizeCreamsConsole(200, 40);

Console.OutputEncoding = Encoding.UTF8;

    



//Console.SetWindowSize(200, 50); //                  deze functie kan alleen na de setup gecalled anders een infite loop en geen terminal





 Conbox inoutline = BoxOutline.createBoxOutline(conboxFunc.MainBody);





 static valueBar initbar(Conbox inoutline, UCOORD pos ,string  barname){
    valueBar Bar = new valueBar();
    Bar.parentBox = inoutline;
    Bar.startpos = pos;
    Bar.BarName = barname; 

    return Bar;
}


Task bar = Task.Run(() => {
    valueBar spotifyBar = initbar(inoutline, new UCOORD(5, 0), "spotify");
    //Task.Delay(500).Wait();

    for (int i = 0; i < 101; i++) {
        spotifyBar.DisplayValueBoxQueue(wueeejn,i);
       
        
    
    }

    return Task.CompletedTask;

    


    
    
    
    

});
valueBar discordBar = initbar(inoutline, new UCOORD(5, Console.WindowHeight / 4), "discord");
Task bar2m = Task.Run(() =>
{
    
    

    for (int i = 0; i < 101; i++)
    {
        discordBar.DisplayValueBoxQueue(wueeejn,i);
        // simulate some work
        //Thread.Sleep(100);


    }

}); 

var termwritereqstyle = new WritingStyle(Color.Red); 


UCOORD zeroone = new UCOORD(0, 1);

var boxinfo = inoutline.GetBoxinfo;

TermialWriterequest  termialWriterequest = new TermialWriterequest(boxinfo,"ik ben een termial write request", zeroone+zeroone,termwritereqstyle );




//onboxFunc.BoxInfoWrite(boxinfo,conboxFunc.ZeroZero,"ik ben een test message van boxinfo" );

//conboxFunc.BoxInfoWrite(termialWriterequest);











Console.ReadKey();