﻿using CreamsConsole_utils;


MultiSelectionMenu.config config = new MultiSelectionMenu.config() { };

config.AddChoise("Option 1", "returnID 1", true); //add a option with Title: option 1, a returnID and set the option to true
config.AddChoise("Option 2", "returnID 2");// add a option with Title: option 2, a returnID and set the option to false
config.AddChoise("Option 3", true); //add a option with Title: option 3, a returnID = option title and set the option to true
config.title = "Im a title"; //Set the Menu title  
config.description = "im a discription"; // Set the menu discription 

MultiSelectionMenu.ReturnedData Output = MultiSelectionMenu.runtimeMenu(config);

if (Output.isSaved) { for (int i = 0; i < Output.returnIDS.Count; i++) { Console.WriteLine($"{Output.returnIDS[i]} -> {Output.returnDict[Output.returnIDS[i]]}"); } }
