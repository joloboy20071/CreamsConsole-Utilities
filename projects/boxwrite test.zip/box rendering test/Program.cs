﻿using CreamsConsole_utils;

graph.Graph graps = new graph.Graph();


graps.setGraphConsoleSize(5,5);

Console.WriteLine(graps.Graphconsoleheight);
