﻿using CreamsConsole_utils;
using System.Drawing;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;

int collum = (Console.BufferWidth / 5);
int row = (Console.BufferHeight / 3);

var box1 = Boxrendering.RenderBoxAtplace(collum * 3, (row * 2) + 1, new Location((0 * collum), 0), "Box 1");
var box21 = Boxrendering.RenderBoxAtplace(collum * 1, (row * 1) + 1, new Location((3 * collum), 0), "BOX 2.1");
var box22 = Boxrendering.RenderBoxAtplace((collum * 1), (row * 1) + 1, new Location((3 * collum), (row * 1)), "BOX 2.2");
var box3 = Boxrendering.RenderBoxAtplace(collum * 5, (row * 1) + 1, new Location(0, (row * 2)), "BOX 3",Color.Magenta);



Console.ReadKey();
Console.SetCursorPosition(Console.BufferWidth - 1, Console.BufferHeight - 1);